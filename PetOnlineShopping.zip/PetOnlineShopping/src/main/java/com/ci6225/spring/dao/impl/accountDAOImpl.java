package com.ci6225.spring.dao.impl;

import javax.transaction.Transactional;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;

import com.ci6225.spring.dao.accountDAO;
import com.ci6225.spring.entity.UserAccount;

@Transactional
public class accountDAOImpl implements accountDAO{
	
	@Autowired
	private SessionFactory sessionFactory;
	
	public UserAccount findAccount(String userName) {
		Session session = sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(UserAccount.class);
		criteria.add(Restrictions.eq("userName", userName));
		return (UserAccount) criteria.uniqueResult();
		
	}

}
