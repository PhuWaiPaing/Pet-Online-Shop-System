package com.ci6225.spring.dao.impl;


import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.springframework.transaction.annotation.Transactional;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;

import com.ci6225.spring.dao.orderDAO;
import com.ci6225.spring.entity.Order;
import com.ci6225.spring.entity.OrderDetails;
import com.ci6225.spring.entity.Puppy;
import com.ci6225.spring.model.CartInfo;
import com.ci6225.spring.model.CartLineInfo;
import com.ci6225.spring.model.CustomerInfo;
import com.ci6225.spring.model.OrderDetailsInfo;
import com.ci6225.spring.model.OrderInfo;
import com.ci6225.spring.model.Pagination;
import com.ci6225.spring.dao.*;


@Transactional
public class orderDAOImpl implements orderDAO{
	
	@Autowired
	private SessionFactory sessionFactory;
	
	@Autowired
	private productDAO productDAO;
	
    private int getMaxOrderNum() {
        String sql = "Select max(o.orderNum) from " + Order.class.getName() + " o ";
        Session session = sessionFactory.getCurrentSession();
        Query query = session.createQuery(sql);
        Integer value = (Integer) query.uniqueResult();
        if (value == null) {
            return 0;
        }
        return value;
    }
    public void saveOrder(CartInfo cartInfo) {
        Session session = sessionFactory.getCurrentSession();
 
        int orderNum = this.getMaxOrderNum() + 1;
        Order order = new Order();
 
        order.setId(UUID.randomUUID().toString());
        order.setOrderNum(orderNum);
        order.setOrderDate(new Date());
        order.setAmount(cartInfo.getAmountTotal());
 
        CustomerInfo customerInfo = cartInfo.getCustomerInfo();
        order.setCustomerName(customerInfo.getName());
        order.setCustomerEmail(customerInfo.getEmail());
        order.setCustomerPhone(customerInfo.getPhone());
        order.setCustomerAddress(customerInfo.getAddress());
 
        session.persist(order);
 
        List<CartLineInfo> lines = cartInfo.getCart();
 
        for (CartLineInfo line : lines) {
            OrderDetails detail = new OrderDetails();
            detail.setId(UUID.randomUUID().toString());
            detail.setOrder(order);
            detail.setAmount(line.getAmount());
            detail.setPrice(line.getProductInfo().getPuppyPrice());
            detail.setQuantity(line.getQuantity());
 
            String code = line.getProductInfo().getPuppyCode();
            Puppy product = this.productDAO.findProduct(code);
            detail.setPuppy(product);
 
            session.persist(detail);
        }
 
        // Set OrderNum for report.
        cartInfo.setOrderNum(orderNum);
    }
	
	   public Pagination<OrderInfo> listOrderInfo(int page, int maxResult, int maxNavigationPage) {
	        String sql = "Select new " + OrderInfo.class.getName()
	                + "(ord.id, ord.orderDate, ord.orderNum, ord.amount, "
	                + " ord.customerName, ord.customerAddress, ord.customerEmail, ord.customerPhone) " + " from "
	                + Order.class.getName() + " ord "
	                + " order by ord.orderNum desc";
	        Session session = this.sessionFactory.getCurrentSession();
	 
	        Query query = session.createQuery(sql);
	 
	        return new Pagination<OrderInfo>(query, page, maxResult, maxNavigationPage);
	    }
	   
	public Order findOrder(String orderId) {
		Session session = sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(Order.class);
		criteria.add(Restrictions.eq("orderId",orderId));
		return (Order)criteria.uniqueResult();
	}
	
	public OrderInfo getOrderInfo(String orderId) {
		Order order = this.findOrder(orderId);
		if (order == null) {
			return null;
		}
		return new OrderInfo(order.getId(), order.getOrderDate(), order.getOrderNum(),
				order.getAmount(),order.getCustomerAddress(),order.getCustomerEmail(),order.getCustomerName(),
				order.getCustomerPhone(), null);
	}
	
	public List<OrderDetailsInfo> listOrderDetails(String orderId){
		String sql = "Select new" + OrderDetailsInfo.class.getName() + "(d.id,d.puppy.code, d.puppy.name,d.quantity, d.price, d.amount)"
						+ "from"+ OrderDetails.class.getName()+"d" + "where d.order.id = :orderId";
		Session session = this.sessionFactory.getCurrentSession();
		Query q = session.createQuery(sql);
		q.setParameter("orderId", orderId);
		return q.list();
	}

}
