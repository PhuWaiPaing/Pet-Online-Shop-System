package com.ci6225.spring.dao;

import com.ci6225.spring.entity.UserAccount;

public interface accountDAO {
	public UserAccount findAccount(String userName);

}
