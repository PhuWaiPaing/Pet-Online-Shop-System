package com.ci6225.spring.dao;

import com.ci6225.spring.entity.Puppy;
import com.ci6225.spring.model.Pagination;
import com.ci6225.spring.model.ProductInfo;


public interface productDAO {
	
	public Puppy findProduct(String code);
	public ProductInfo findProductInfo(String code);

    public Pagination<ProductInfo> queryProducts(int page,
                       int maxResult, int maxNavigationPage);
    
    public Pagination<ProductInfo> queryProducts(int page, int maxResult,
                       int maxNavigationPage, String likeName);
	public void save(ProductInfo productInfo);
}
