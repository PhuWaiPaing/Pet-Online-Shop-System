package com.ci6225.spring.dao;

import java.util.List;

import com.ci6225.spring.model.CartInfo;
import com.ci6225.spring.model.OrderDetailsInfo;
import com.ci6225.spring.model.OrderInfo;
import com.ci6225.spring.model.Pagination;

public interface orderDAO {
	public void saveOrder(CartInfo cartInfo);
	public Pagination <OrderInfo> listOrderInfo(int page, int maxResult, int maxNavigationPage);
	public OrderInfo getOrderInfo(String orderId);
	public List<OrderDetailsInfo> listOrderDetails(String orderId);

}
