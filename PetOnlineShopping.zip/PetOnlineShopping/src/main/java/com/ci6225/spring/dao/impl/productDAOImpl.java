package com.ci6225.spring.dao.impl;

import java.util.Date;

import javax.transaction.Transactional;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;

import com.ci6225.spring.dao.productDAO;
import com.ci6225.spring.entity.Puppy;
import com.ci6225.spring.model.Pagination;
import com.ci6225.spring.model.ProductInfo;

@SuppressWarnings("deprecation")
@Transactional
public class productDAOImpl implements productDAO{
	
	@Autowired
	private SessionFactory sessionFactory;
	
	public Puppy findProduct(String code) {
		Session session = sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(Puppy.class);
		criteria.add(Restrictions.eq("code",code));
		return (Puppy) criteria.uniqueResult();
	}
	
	public ProductInfo findProductInfo(String code) {
		Puppy puppy = this.findProduct(code);
		if (puppy == null) {
			return null;
		}
		return new ProductInfo(puppy.getCode(),puppy.getName(),puppy.getGender(), puppy.getPrice());
	}
	
	public void save(ProductInfo productInfo) {
		String code = productInfo.getPuppyCode();
		Puppy puppy = null;
		
		boolean isNew = false;
		if (code != null) {
			puppy = this.findProduct(code); 
		}
		if (puppy == null) {
			isNew = true;
			puppy = new Puppy();
			puppy.setCreateDate(new Date());
		}
		puppy.setCode(code);
		puppy.setName(productInfo.getPuppyName());
		puppy.setGender(productInfo.getPuppyGender());
		puppy.setPrice(productInfo.getPuppyPrice());
		
		if (productInfo.getFile() != null) {
			byte[] image = productInfo.getFile().getBytes();
			if (image != null && image.length > 0) {
				puppy.setImage(image);
			}
		}
		if(isNew) {
			this.sessionFactory.getCurrentSession().persist(puppy);
		}
		this.sessionFactory.getCurrentSession().flush();
	}
	
	public Pagination<ProductInfo> queryProducts(int page, int maxResult, int maxNavigationPage,
            String likeName) {
        String sql = "Select new " + ProductInfo.class.getName()
                + "(p.code, p.name, p.gender, p.price) " + " from "
                + Puppy.class.getName() + " p ";
        if (likeName != null && likeName.length() > 0) {
            sql += " Where lower(p.name) like :likeName ";
        }
        sql += " order by p.createDate desc ";
        //
        Session session = sessionFactory.getCurrentSession();
 
        Query query = session.createQuery(sql);
        if (likeName != null && likeName.length() > 0) {
            query.setParameter("likeName", "%" + likeName.toLowerCase() + "%");
        }
        return new Pagination<ProductInfo>(query, page, maxResult, maxNavigationPage);
    }
 
    public Pagination<ProductInfo> queryProducts(int page, int maxResult, int maxNavigationPage) {
        return queryProducts(page, maxResult, maxNavigationPage, null);
    }
    
}
