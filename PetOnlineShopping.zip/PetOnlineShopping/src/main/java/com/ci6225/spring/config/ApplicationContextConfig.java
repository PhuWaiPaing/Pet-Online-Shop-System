package com.ci6225.spring.config;

import java.util.Properties;

import javax.sql.DataSource;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.hibernate5.HibernateTransactionManager;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;
import org.springframework.web.servlet.view.InternalResourceViewResolver;


import com.ci6225.spring.dao.orderDAO;
import com.ci6225.spring.dao.productDAO;
import com.ci6225.spring.dao.impl.orderDAOImpl;
import com.ci6225.spring.dao.impl.productDAOImpl;

@Configuration
@ComponentScan("com.ci6225.spring.*")
@EnableTransactionManagement
@PropertySource("classpath:database-hibernate.properties")
public class ApplicationContextConfig {
	
	//The Environment class serves as the property holder
	//and stores all the properties loaded by the @PropertySource
	@Autowired
	private Environment env;
	
	@Bean
	public ResourceBundleMessageSource messageSource() {
		ResourceBundleMessageSource rb = new ResourceBundleMessageSource();
		//Load property in message/validator.properties
		rb.setBasenames(new String[] {"messages/validator"});
		return rb;
		
	}
	
	@Bean(name="viewResolver")
	public InternalResourceViewResolver getViewResolver() {
		InternalResourceViewResolver resource = new InternalResourceViewResolver();
		resource.setPrefix("/WEB-INF/pages/");
		resource.setSuffix(".jsp");
		return resource;
	}
	
	@Bean(name = "multipartResolver")
    public CommonsMultipartResolver multipartResolver() {
        CommonsMultipartResolver commonsMultipartResolver = new CommonsMultipartResolver();
        return commonsMultipartResolver;
    }
	
	@Bean(name="dataSource")
	public DataSource getDataSource() {
		DriverManagerDataSource dataSource = new DriverManagerDataSource();
		
		dataSource.setDriverClassName(env.getProperty("ds.database-driver"));
		dataSource.setUrl(env.getProperty("ds.url"));
		dataSource.setUsername(env.getProperty("ds.username"));
		dataSource.setPassword(env.getProperty("ds.password"));
		return dataSource;
		
	}
	
	@Autowired
	@Bean(name="sessionFactory")
	public SessionFactory getSessionFactory(DataSource dataSource) throws Exception{
		Properties prop = new Properties();
		prop.put("hibernate.dialect", env.getProperty("hibernate.dialect"));
		prop.put("hibernate.show_sql", env.getProperty("hibernate.show_sql"));
		prop.put("current_session_context_class", env.getProperty("current_session_context_class"));
		
		LocalSessionFactoryBean factoryBean = new LocalSessionFactoryBean();
		
		factoryBean.setPackagesToScan(new String[] {"com.ci6225.spring.entity"});
		factoryBean.setDataSource(dataSource);
		factoryBean.setHibernateProperties(prop);
		factoryBean.afterPropertiesSet();
		
		SessionFactory sessionFactory = factoryBean.getObject();
		return sessionFactory;
	}
	
	@Autowired
	@Bean(name="transactionManager")
	public HibernateTransactionManager getTransactionManager(SessionFactory sf) {
		HibernateTransactionManager transactionManager = new HibernateTransactionManager(sf);
		return transactionManager;
	}
		
	@Bean(name="productDAO")
	public productDAO getPuppyDAO() {
		return new productDAOImpl();
	}
	
	@Bean(name="orderDAO")
	public orderDAO getorderDAO() {
		return new orderDAOImpl();
	}

}
